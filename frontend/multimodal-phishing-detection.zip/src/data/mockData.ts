// Mock Data for Deepfake Analysis
export const deepfakeData = [
  { frame: 0, probability: 0.12 },
  { frame: 10, probability: 0.15 },
  { frame: 20, probability: 0.88 },
  { frame: 30, probability: 0.95 },
  { frame: 40, probability: 0.92 },
  { frame: 50, probability: 0.45 },
  { frame: 60, probability: 0.10 },
];

// Mock Data for Text Highlighting (SHAP/LIME)
export const phishingText = [
  { text: "[국제발신] ", weight: 0.1 },
  { text: "고객님, ", weight: 0.05 },
  { text: "비정상적인 로그인 시도가 감지되었습니다. ", weight: 0.7 },
  { text: "본인이 아닐 경우 ", weight: 0.2 },
  { text: "즉시 아래 링크를 클릭하여 ", weight: 0.9 },
  { text: "계정을 보호하십시오. ", weight: 0.8 },
  { text: "https://kb-secure.com/auth", weight: 1.0 }
];

export const incidents = [
  { id: '2024-0323-09', type: '피싱 텍스트', risk: 'High' as const, conf: '98.2%', time: '09:58:17', status: '분석 중' },
  { id: '2024-0323-08', type: '딥페이크', risk: 'Medium' as const, conf: '85.4%', time: '09:45:12', status: '대기' },
  { id: '2024-0323-07', type: '피싱 텍스트', risk: 'High' as const, conf: '99.1%', time: '09:32:45', status: '대기' },
  { id: '2024-0323-06', type: '복합 위협', risk: 'Low' as const, conf: '42.0%', time: '09:12:05', status: '완료' },
];
